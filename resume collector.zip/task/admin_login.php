<?php
error_reporting(0);
session_start();
include('config.php');
              

$msg = $_GET['msg'];
if($msg!="")
{
	echo $msg;
}




if (isset($_POST['Save1'])) {

  $username = $_POST['username'];
  $password = $_POST['password'];
  

  $checkuser = mysqli_query($conn,"select * from settingmaster where `company_name`='$username' AND `admin_password`='$password'");

  $count = mysqli_num_rows($checkuser);
		if($count==1){
      $_SESSION['username'] = $username;
  

    $success_msg = "Login successfully!";
    header("location: dashboard.php");
} else {
  $error_msg = "Please Enter Valid Details!";
}

    
  
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>admin_login</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</head>
<body>

<?php
                if ($success_msg != "") {
                    ?>
                    <div class="alert alert-success">
                        <strong>Success!</strong>
                        <?php echo $success_msg; ?>
                    </div>
                    <?php
                }
                if ($error_msg != "") {
                    ?>
                    <div class="alert alert-danger">
                        <strong>Error!</strong>
                        <?php echo $error_msg; ?>
                    </div>
                    <?php
                }
                ?>
    
<form action="admin_login.php" method="post">
    
<div class="container col-md-4 mt-5 pt-3 bg-#adb5bd border border-secondary " style="background-color:#f0f2f5">
<h1 style="text-align: center; font-size:30px">Login</h1>
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Username</label>
    <input type="text" class="form-control" name="username">
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Password</label>
    <input type="password" class="form-control" name="password">
  </div>
  
  <button type="submit" class="btn btn-primary" style="margin-bottom: 10px;" name="Save1">Login</button>
    </div>

</form>


</body>
</html>