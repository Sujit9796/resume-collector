-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 27, 2023 at 08:16 AM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `resume_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `applicationtypemaster`
--

DROP TABLE IF EXISTS `applicationtypemaster`;
CREATE TABLE IF NOT EXISTS `applicationtypemaster` (
  `application_id` int NOT NULL AUTO_INCREMENT,
  `app_type` text,
  `description_app` text,
  PRIMARY KEY (`application_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `applicationtypemaster`
--

INSERT INTO `applicationtypemaster` (`application_id`, `app_type`, `description_app`) VALUES
(5, 'Apply For Job', 'mcs'),
(10, 'Apply For Intranship', 'bcs'),
(11, 'Apply For Job', 'mcs'),
(12, 'Apply For Intranship', 'bcs');

-- --------------------------------------------------------

--
-- Table structure for table `educationstatusmaster`
--

DROP TABLE IF EXISTS `educationstatusmaster`;
CREATE TABLE IF NOT EXISTS `educationstatusmaster` (
  `education_id` int NOT NULL AUTO_INCREMENT,
  `education_status` text,
  `education_desc` text,
  PRIMARY KEY (`education_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `educationstatusmaster`
--

INSERT INTO `educationstatusmaster` (`education_id`, `education_status`, `education_desc`) VALUES
(1, 'bcs pursing', 'bvcvh'),
(2, 'bcs pursing', 'sfgsg'),
(6, 'mcs', 'mcs pursing'),
(7, 'mcs', 'mcs pursing sdf');

-- --------------------------------------------------------

--
-- Table structure for table `employeemaster`
--

DROP TABLE IF EXISTS `employeemaster`;
CREATE TABLE IF NOT EXISTS `employeemaster` (
  `employee_id` int NOT NULL AUTO_INCREMENT,
  `emp_name` text,
  `email_id` text,
  `mobile_no` text,
  PRIMARY KEY (`employee_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `employeemaster`
--

INSERT INTO `employeemaster` (`employee_id`, `emp_name`, `email_id`, `mobile_no`) VALUES
(1, 'sujit', 'sujit@gmail.com', '7283254589'),
(3, 'raj', 'raj@gmail.com', '70832121133'),
(4, 'nagesh', 'nagesh@gmail.com', '7585893123'),
(5, 'suraj', 'suraj@gmail.com', '9874561223'),
(6, 'sujit', 'suraj@gmail.com', '9874561223');

-- --------------------------------------------------------

--
-- Table structure for table `loginmaster`
--

DROP TABLE IF EXISTS `loginmaster`;
CREATE TABLE IF NOT EXISTS `loginmaster` (
  `login_id` int NOT NULL AUTO_INCREMENT,
  `username` text,
  `password` text,
  PRIMARY KEY (`login_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `loginmaster`
--

INSERT INTO `loginmaster` (`login_id`, `username`, `password`) VALUES
(36, 'TRON Softech', 'sujit'),
(37, 'TRON Softech', 'sujit'),
(38, 'TRON Softech', 'sujit'),
(39, 'TRON Softech', 'sujit');

-- --------------------------------------------------------

--
-- Table structure for table `resumemaster`
--

DROP TABLE IF EXISTS `resumemaster`;
CREATE TABLE IF NOT EXISTS `resumemaster` (
  `resume_id` int NOT NULL AUTO_INCREMENT,
  `application_type` text,
  `education_status` text,
  `profile_photo` text,
  `course_name` text,
  `stream` text,
  `college_name` text,
  `passing_year` text,
  `fullname` text,
  `email` text,
  `mobile` text,
  `dob` text,
  `gender` text,
  `address` text,
  `resume` text,
  `primary_ref` text,
  `secondary_ref` text,
  `createon` date NOT NULL,
  PRIMARY KEY (`resume_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `resumemaster`
--

INSERT INTO `resumemaster` (`resume_id`, `application_type`, `education_status`, `profile_photo`, `course_name`, `stream`, `college_name`, `passing_year`, `fullname`, `email`, `mobile`, `dob`, `gender`, `address`, `resume`, `primary_ref`, `secondary_ref`, `createon`) VALUES
(32, '5', '1', 'sir.jpg', 'php', 'computer science', 'T C College Baramati', '2022', 'sujit shinde', 'sujit@gmail.com', '7083222716', '2000-04-04', 'Male', 'A/p Wathar Nimbalkar', 'Sujit Shinde Resume.pdf', '5', 'college', '2023-02-09'),
(33, '5', '1', 'sir.jpg', 'php', 'computer science', 'T C College Baramati', '2022', 'sujit shinde', 'sujit@gmail.com', '7083222716', '2000-04-04', 'Male', 'A/p Wathar Nimbalkar', 'Sujit Shinde Resume.pdf', '5', 'college', '2023-02-10'),
(34, '10', '3', 'stud1.jpg', 'raj@gmail.com', 'computer ', 'Y C College satara', '2022', 'raj jadhav', 'raj@gmail.com', '7083212112', '1998-06-03', 'Male', 'A/p satara ', 'Tambe ajay 23.pdf', '4', 'NA', '2023-02-10'),
(35, '10', '3', 'stud1.jpg', 'raj@gmail.com', 'computer ', 'Y C College satara', '2022', 'raj jadhav', 'raj@gmail.com', '7083212112', '1998-06-03', 'Male', 'A/p satara ', 'Tambe ajay 23.pdf', '4', 'NA', '2023-02-10'),
(36, '10', '3', 'stud1.jpg', 'raj@gmail.com', 'computer ', 'Y C College satara', '2022', 'raj jadhav', 'raj@gmail.com', '7083212112', '1998-06-03', 'Male', 'A/p satara ', 'Tambe ajay 23.pdf', '4', 'NA', '2023-02-10'),
(37, '10', '3', 'stud1.jpg', 'android', 'computer ', 'Y C College satara', '2020', 'raj jadhav', 'raj@gmail.com', '7083212112', '1998-03-18', '', 'A/p satara', 'Tambe ajay 23.pdf', '4', 'NA', '2023-02-10'),
(38, '10', '3', 'stud1.jpg', 'android', 'computer ', 'Y C College satara', '2020', 'raj jadhav', 'raj@gmail.com', '7083212112', '1998-03-18', '', 'A/p satara', 'Tambe ajay 23.pdf', '4', 'NA', '2023-02-13'),
(39, '10', '2', 'stud1.jpg', 'php', 'computer science', 'T C College Baramati', '2022', 'sujit shinde', 'raj@gmail.com', '7083212112', '2023-02-15', 'Male', 'A/p hadpser', 'ajay tambe1999-1.pdf', '3', 'college', '2023-02-15');

-- --------------------------------------------------------

--
-- Table structure for table `settingmaster`
--

DROP TABLE IF EXISTS `settingmaster`;
CREATE TABLE IF NOT EXISTS `settingmaster` (
  `admin_id` int NOT NULL AUTO_INCREMENT,
  `company_name` text,
  `company_logo` text,
  `tag_line` text,
  `address` text,
  `admin_password` text,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `settingmaster`
--

INSERT INTO `settingmaster` (`admin_id`, `company_name`, `company_logo`, `tag_line`, `address`, `admin_password`) VALUES
(1, 'TRON Softech', 'download2.jpg', 'Design, Develop, Deploy.', 'TRON Softech, 4th Floor, Dashmesh Complex, Near Pranaam Hotel,, Pune-Solapur Road, Gadital, Hadapsar, Pune, Maharashtra 411028', 'sujit');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
