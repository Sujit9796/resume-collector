<?php
error_reporting(0);
            include('config.php');
            session_start();
            $session_username = $_SESSION['username'];
if($session_username=="")
{
 header("Location: logout.php");
}
// $todaysdate = date("y-m-d");
if (isset($_POST['Save1'])) {

  $app_type = $_POST['app_type'];
  $description_app = $_POST['description_app'];
  

  if ($app_type != "" && $description_app != "") {

    // $sql = mysqli_query($conn, "INSERT INTO `employeemaster` (`employee_id`, `fullname`, `emp_code`, `mobile`, `city`, `salary`, `createon`) VALUES (NULL, '$fullname', '$emp_code', '$mobile', '$city', '$salary','$todaysdate')");


    $insert = mysqli_query($conn, "insert into `applicationtypemaster`
	set 
	`app_type`='$app_type',
	`description_app`='$description_app'
	
	");

    // $lastempid = mysqli_insert_id($conn);

    $success_msg = "Employee added successfully!";
} else {
  $error_msg = "Please enter application_type & description_app!";
}


}       


?>

<?php include('navbar.php'); ?>

<body>

<?php
                if ($success_msg != "") {
                    ?>
                    <div class="alert alert-success">
                        <strong>Success!</strong>
                        <?php echo $success_msg; ?>
                    </div>
                    <?php
                }
                if ($error_msg != "") {
                    ?>
                    <div class="alert alert-danger">
                        <strong>Error!</strong>
                        <?php echo $error_msg; ?>
                    </div>
                    <?php
                }
                ?>

    <div class="container mb-3 col-md-4 pt-5" >

        <h2 class="text-center text-secondary mb-4">Application Type</h2>
        <form action="application_type.php" method="post" class=" border border-secondary " style="background-color:#f0f2f5">



            <div class="mb-3 col-md-9  mx-5 mt-3">
                <label for="" class="form-label mb-3"> Application Type</label>
                <input type="text" class="form-control mb-4 " id="" name="app_type">
            </div>
            <div class="form-floating col-md-9 mx-5">
                <textarea class="form-control mb-3" placeholder="Description " name="description_app"></textarea>
                <label for="floatingTextarea">Description</label>
            </div>

            <div class="text-center mx-5">
                <input type="submit" class="btn btn-primary col-md-3 text-center   mx-3  mb-3" name="Save1" value="Save">
                <button class="btn btn-primary mt-2 mb-4">
                   <a href="application_type_list.php" class="text-white col-md-3 text-center  mx-3  mb-3 text-decoration-none">Cancel</a>
                </button>
            </div>
        </form>
    </div>

</body>

</html>