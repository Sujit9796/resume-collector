<?php
      error_reporting(0);
            include('config.php');
            session_start();
                $session_username = $_SESSION['username'];
 if($session_username=="")
 {
	 header("Location: logout.php");
 }

                $education_id = $_GET['education_id'];

                if($education_id!= "") 
{
  $deleterecord = mysqli_query($conn, "delete from `educationstatusmaster` where `education_id`='$education_id'");
	$success_msg = "Record Deleted Successfully!";
  echo $success_msg;
}

?>

<!DOCTYPE html>
<html>
<head>
<style>

</style>
</head>
<body>

<?php include('navbar.php'); ?>

<div class="text-end mx-5 mt-4">
  <button class="btn btn-secondary mt-3 mb-3">
    <a href="education_status.php" class="text-white text-decoration-none">Add Education Status</a>
  </button>
</div>

<h4 class="mb-4 text-center py-3">List Of Education Status</h4>
<!-- <table id="customers"> -->
<table class="table table-bordered table-hover">
  <thead class=" bg-secondary text-white">
  <div class="container-fluid">
  <tr>
    <th>Education ID</th>
    <th>Education Status</th>
    <th>Education Description</th>
    <th>Edit</th>
    <th>Delete</th>
	 
  </tr>
  </div>
  </thead>

  <?php
   $selectquery = mysqli_query($conn, "select * from `educationstatusmaster`");

  while ($fetchdata = mysqli_fetch_array($selectquery)) {
      $education_id = $fetchdata['education_id'];
      $education_status = $fetchdata['education_status'];
      $education_desc = $fetchdata['education_desc'];

      ?>

<td><?php echo $education_id; ?></td>
	<td><?php echo $education_status; ?></td>
	<td><?php echo $education_desc; ?></td>
	
	<!-- <td><a href="add_photo.php?education_id=<?php //echo $education_id; ?>">Add Photo</a></td> -->

	<!-- <td><a href="view_employee.php?education_id=<?php //echo $education_id; ?>">View</a></td> -->
	<td><a href="education_status_update.php?education_id=<?php echo $education_id; ?>">Edit</a></td>
	<td><a href="education_status_list.php?education_id=<?php echo $education_id; ?>" onclick="return confirm('do you want to delete this record?');">Delete</a></td>
	 
	</tr>
   <?php

        }

   ?>

</table>
</body>
</html>