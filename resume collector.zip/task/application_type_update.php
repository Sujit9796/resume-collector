<?php
error_reporting(0);
            include('config.php');
                session_start();
$application_id = $_GET['application_id'];
// $todaysdate = date("y-m-d");
if (isset($_POST['Save1'])) {

  $app_type = $_POST['app_type'];
  $description_app = $_POST['description_app'];
  

  if ($app_type != "" && $description_app != "") {

        
    $update = "UPDATE `applicationtypemaster`
    set
 
    `app_type`='$app_type',
    `description_app`='$description_app'
   
    WHERE `application_id` =$application_id";
     $data = mysqli_query($conn, $update);

        $success_msg = " Update Succefully !";
    } else {
        $error_msg = "Error  !";
    }
    ;


    // $lastempid = mysqli_insert_id($conn);



}     



$selectquery = mysqli_query($conn, "select * from `applicationtypemaster` where application_id = '$application_id'");

while ($fetchdata = mysqli_fetch_array($selectquery)) {
    $application_id = $fetchdata['application_id'];
    $app_type = $fetchdata['app_type'];
    $description_app = $fetchdata['description_app'];



}

?>
<body>

<?php include('navbar.php'); ?>



<?php
                if ($success_msg != "") {
                    ?>
                    <div class="alert alert-success">
                        <strong>Success!</strong>
                        <?php echo $success_msg; ?>
                    </div>
                    <?php
                }
                if ($error_msg != "") {
                    ?>
                    <div class="alert alert-danger">
                        <strong>Error!</strong>
                        <?php echo $error_msg; ?>
                    </div>
                    <?php
                }
                ?>

    <div class="container  mb-3 col-md-4 pt-5" >
    <h2 class="text-center text-secondary">Application Type</h2>
        <form action="application_type_update.php?application_id=<?php echo $application_id; ?>" method="post" class=" border border-secondary mt-4 pt-4" style="background-color:#f0f2f5">
            



            <div class="mb-3 col-md-9  mx-5 mt-3">
                <label for="" class="form-label mb-3"> Application Type</label>
                <input type="text" class="form-control py-2 " id="" name="app_type" value="<?php echo $app_type; ?>">
            </div>

            
            <div class="mb-3 col-md-9  mx-5 mt-3">
                <label for="" class="form-label mb-3"> Description </label>
                <input type="text" class="form-control py-2" id="" name="description_app" value="<?php echo $description_app; ?>">
            </div>
           

            <div class="text-center">
                <input type="submit" class="btn btn-primary col-md-2 " name="Save1" value="Save">
                <button type="submit" class="btn btn-primary text-center mb-3 mt-3 mx-3">
                <a href="application_type_list.php " class="text-white text-decoration-none mx-2 my-2">Cancel</a>
                </button>
            </div>
        </form>
    </div>

</body>

</html>