<?php
error_reporting(0);
            include('config.php');
            session_start();
            $session_username = $_SESSION['username'];
if($session_username=="")
{
 header("Location: logout.php");
}
// $todaysdate = date("y-m-d");
if (isset($_POST['Save1'])) {

  $education_status = $_POST['education_status'];
  $education_desc = $_POST['education_desc'];
  

  if ($education_status != "" && $education_desc != "") {

    

    // $sql = mysqli_query($conn, "INSERT INTO `employeemaster` (`employee_id`, `fullname`, `emp_code`, `mobile`, `city`, `salary`, `createon`) VALUES (NULL, '$fullname', '$emp_code', '$mobile', '$city', '$salary','$todaysdate')");


    $insert = mysqli_query($conn, "insert into `educationstatusmaster`
	set 
	`education_status`='$education_status',
	`education_desc`='$education_desc'
	
	");

    // $lastempid = mysqli_insert_id($conn);

    $success_msg = "Employee added successfully!";
} else {
  $error_msg = "Please enter application_type & description_app!";
}


}       

?>

<?php include('navbar.php'); ?>


<body>

<?php
                if ($success_msg != "") {
                    ?>
                    <div class="alert alert-success">
                        <strong>Success!</strong>
                        <?php echo $success_msg; ?>
                    </div>
                    <?php
                }
                if ($error_msg != "") {
                    ?>
                    <div class="alert alert-danger">
                        <strong>Error!</strong>
                        <?php echo $error_msg; ?>
                    </div>
                    <?php
                }
                ?>

<h2 class="text-center text-secondary mt-4">Education Status</h2>
    <div class="container  mb-3 col-md-4 pt-5">

        <form action="education_status.php" method="post" class=" border border-secondary " style="background-color:#f0f2f5">



            <div class="mb-3 col-md-9  mx-5 mt-3">
                <label for="" class="form-label mb-3"> Education Status</label>
                <input type="text" class="form-control " id="" name="education_status">
            </div>
            <div class="form-floating col-md-9 mx-5">
                <textarea class="form-control" placeholder="Description " name="education_desc"></textarea>
                <label for="floatingTextarea">Description</label>
            </div>

            <div class="text-center mt-3 mb-3">
                <input type="submit" class="btn btn-primary col-md-3 text-center   mx-3  mb-3" name="Save1" value="Save">
                <button class="btn btn-primary mt-2 mb-4">
                   <a href="education_status_list.php" class="text-white col-md-3 text-center  mx-3  mb-3 text-decoration-none">Cancel</a>
                </button>
            </div>
        </form>
    </div>

</body>

</html>