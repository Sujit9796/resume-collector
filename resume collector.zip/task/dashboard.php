<?php
error_reporting(0);
        include('config.php');
       
        session_start();
                $session_username = $_SESSION['username'];
 if($session_username=="")
 {
	 header("Location: logout.php");
 }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DashBoard</title>
    <style>
   
</style>

</head>
<body>

<?php include('navbar.php'); ?>

<h2 style="text-align: center; margin-top:15px; margin-bottom:15px;">DashBoard</h2> 

<table class="table table-bordered table-hover">
  <thead class=" bg-secondary text-white">
  <div class="container-fluid">
  <tr>
    <th>Resume ID</th>
    <th>Full Name</th>
    <th>Application Type</th>
	<th>Education Status</th>
    <th>Year Of passing</th>
    <th>Primary ref</th>
    <th>Date</th>
    <th>View</th>
  </tr>
  </div>
  </thead>

 <?php
   $selectquery = mysqli_query($conn, "select * from `resumemaster`");

 while ($fetchdata = mysqli_fetch_array($selectquery)) {
      $resume_id = $fetchdata['resume_id'];
      $fullname = $fetchdata['fullname'];
      
      $application_type = $fetchdata['application_type'];

     $selectquery1 = mysqli_query($conn, "SELECT * FROM `applicationtypemaster` where application_id='$application_type'");

     while($data = mysqli_fetch_array($selectquery1)){
         $application_type_name = $data['app_type'];
     }

      $education_status = $fetchdata['education_status'];
      $selectquery2 =  mysqli_query($conn, "SELECT * FROM `educationstatusmaster` where education_id ='$education_status'");
      while($data1 = mysqli_fetch_array($selectquery2)){
        $education_status_name = $data1['education_status'];
      }

      $passing_year = $fetchdata['passing_year'];
    

      $primary_ref = $fetchdata['primary_ref'];
      $selectquery3 =  mysqli_query($conn, "SELECT * FROM `employeemaster` where employee_id ='$primary_ref'");
       while($data2 = mysqli_fetch_array($selectquery3)){
         $primary_ref_name = $data2['emp_name'];
     }
    
     $createon = $fetchdata['createon'];
  ?>

    <td><?php echo $resume_id; ?></td>
	<td><?php echo $fullname; ?></td>
	<td><?php echo $application_type_name; ?></td>
    <td><?php echo $education_status_name; ?></td>
    <td><?php echo $passing_year; ?></td>
    <td><?php echo $primary_ref_name; ?></td>
    <td><?php echo $createon; ?></td>
	

	<td><a href="view_resume.php?resume_id=<?php echo $resume_id; ?>">View</a></td>
	 
	</tr>
   <?php

        }

   ?>
</table>
</body>
</html>