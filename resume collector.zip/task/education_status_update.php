<?php
error_reporting(0);
            include('config.php');
                
                session_start();
                $session_username = $_SESSION['username'];
 if($session_username=="")
 {
	 header("Location: logout.php");
 }

                $education_id = $_GET['education_id'];
// $todaysdate = date("y-m-d");
if (isset($_POST['Save1'])) {

  $education_status = $_POST['education_status'];
  $education_desc = $_POST['education_desc'];
  

  if ($education_status != "" && $education_desc != "") {

    
    $update = "UPDATE `educationstatusmaster`
    set

    `education_status`='$education_status',
    `education_desc`='$education_desc'
    WHERE `education_id` = $education_id";

     $data = mysqli_query($conn, $update);

     $success_msg = " Update Succefully !";
    } else {
        $error_msg = "Error  !";
    }
    

    // $lastempid = mysqli_insert_id($conn);

}     

$selectquery = mysqli_query($conn, "select * from `educationstatusmaster` where education_id = '$education_id'");

while ($fetchdata = mysqli_fetch_array($selectquery)) {
    $education_id = $fetchdata['education_id'];
    $education_status = $fetchdata['education_status'];
    $education_desc = $fetchdata['education_desc'];

}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>education_status_update</title>
</head>
<body>


<?php include('navbar.php'); ?>



<?php
                if ($success_msg != "") {
                    ?>
                    <div class="alert alert-success">
                        <strong>Success!</strong>
                        <?php echo $success_msg; ?>
                    </div>
                    <?php
                }
                if ($error_msg != "") {
                    ?>
                    <div class="alert alert-danger">
                        <strong>Error!</strong>
                        <?php echo $error_msg; ?>
                    </div>
                    <?php
                }
                ?>

<h2 class="text-center text-secondary mt-4">Education Status</h2>
    <div class="container  mb-3 col-md-4 pt-4">

        <form action="education_status_update.php?education_id=<?php echo $education_id; ?>" method="post" class=" border border-secondary " style="background-color:#f0f2f5">



            <div class="mb-3 col-md-9  mx-5 mt-3">
                <label for="" class="form-label mb-3"> Education Status</label>
                <input type="text" class="form-control " id="" name="education_status" value="<?php echo $education_status; ?>">
            </div>

            <div class="mb-3 col-md-9  mx-5 mt-3">
                <label for="" class="form-label mb-3"> Description</label>
                <input type="text" class="form-control " id="" name="education_desc" value="<?php echo $education_desc; ?>">
            </div>
            

            <div class="text-center mt-3 mb-3">
                <input type="submit" class="btn btn-primary col-md-3 text-center   mx-3  mb-3" name="Save1" value="Save">
                <button class="btn btn-primary mt-2 mb-4">
                   <a href="education_status_list.php" class="text-white col-md-3 text-center  mx-3  mb-3 text-decoration-none">Cancel</a>
                </button>
            
            </div>
        </form>
    </div>

</body>

</html>