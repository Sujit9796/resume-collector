<?php
      error_reporting(0);
            include('config.php');
            session_start();
            $session_username = $_SESSION['username'];
if($session_username=="")
{
header("Location: logout.php");
}

               $application_id = $_GET['application_id'];

               if($application_id!= "") 
{
  $deleterecord = mysqli_query($conn, "delete from `applicationtypemaster` where application_id='$application_id' ");
	$success_msg = "Record Deleted Successfully!";
  echo $success_msg;
}

?>

<!DOCTYPE html>
<html>
<head>
<style>

</style>
</head>
<body>
<?php include('navbar.php'); ?>

<div class="text-end mx-5 mt-4">
  <button class="btn btn-secondary mt-3 mb-4 ">
    <a href="application_type.php" class="text-white text-decoration-none">Add Application Type</a>
  </button>
</div>
<h4 class="mb-4 text-center py-3">List Of Application Type</h4>
    <table class="table table-hover table-bordered">
  <thead class=" bg-secondary text-white">
  <div class="container-fluid">
  <tr>
    <th>Application ID</th>
    <th>Application_Type</th>
    <th>Discription</th>
	<th>Edit</th>
	<th>Delete</th>
	 
  </tr>
</div>
  </thead>

  <?php
   $selectquery = mysqli_query($conn, "select * from `applicationtypemaster`");

  while ($fetchdata = mysqli_fetch_array($selectquery)) {
      $application_id = $fetchdata['application_id'];
      $app_type = $fetchdata['app_type'];
      $description_app = $fetchdata['description_app'];


      ?>
<tr class="">
<td><?php echo $application_id; ?></td>
	<td><?php echo $app_type; ?></td>
	<td><?php echo $description_app; ?></td>
	
	
	<td><a href="application_type_update.php?application_id=<?php echo $application_id; ?>">Edit</a></td>
	<td><a href="application_type_list.php?application_id=<?php echo $application_id; ?>" onclick="return confirm('do you want to delete this record?');">Delete</a></td>
</tr>
	</tr>
   <?php

        }

   ?>

</table>
</body>
</html>