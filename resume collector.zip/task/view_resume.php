<?php

error_reporting(0);
include('config.php');

session_start();
                $session_username = $_SESSION['username'];
 if($session_username=="")
 {
	 header("Location: logout.php");
 }


$resume_id = $_GET['resume_id'];
$todaysdate = date('Y-m-d');
// $dec_emp_id = base64_decode($resume_id);
$selectquery = mysqli_query($conn, "select * from `resumemaster` where `resume_id`='$resume_id'");
while($fetchdata = mysqli_fetch_array($selectquery))
{
  $resume_id = $fetchdata['resume_id'];
  $profile_photo = $fetchdata['profile_photo'];
  $fullname = $fetchdata['fullname'];

  $application_type = $fetchdata['application_type'];
  $selectquery1 = mysqli_query($conn, "SELECT * FROM `applicationtypemaster` where application_id='$application_type'");
     while($data = mysqli_fetch_array($selectquery1)){
         $application_type_name = $data['app_type'];
     }

  $education_status = $fetchdata['education_status'];
  $selectquery2 =  mysqli_query($conn, "SELECT * FROM `educationstatusmaster` where education_id ='$education_status'");
  while($data1 = mysqli_fetch_array($selectquery2)){
    $education_status_name = $data1['education_status'];
  }

  $passing_year = $fetchdata['passing_year'];

  $primary_ref = $fetchdata['primary_ref'];
  $selectquery3 =  mysqli_query($conn, "SELECT * FROM `employeemaster` where employee_id ='$primary_ref'");
       while($data2 = mysqli_fetch_array($selectquery3)){
         $primary_ref_name = $data2['emp_name'];
     }
     
  $resume = $fetchdata['resume'];
  $createon = $fetchdata['createon'];
}
?>

<style>
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #04AA6D;
  color: white;
}
</style>

<?php include('navbar.php'); ?>
<button class="btn btn-secondary mt-4 mb-4 ">
<a href="dashboard.php" class="text-decoration-none text-white text-end">DashBoard</a>
</button>

<table id="customers">

		<td>
			<img src="profile_photo/<?php echo $profile_photo; ?>" style="width: 200px; height: 200px;">
		</td>
	 </tr>
   

  <tr>
	<td><b>Resume ID</b></td>
	<td><?php echo $resume_id; ?></td>
	 </tr>
	<tr>
	<td><b>Full Name</b></td>
	<td><?php echo $fullname; ?></td>
	 </tr>

     
	 <tr>
	<td><b>Application Type</b></td>
	<td><?php echo $application_type_name; ?></td>
	 </tr>
	 <tr>
	<td><b>Education Status</b></td>
	<td><?php echo $education_status_name; ?></td>
	 </tr>
	 <tr>
	<td><b>Passing Year</b></td>
	<td><?php echo $passing_year; ?></td>
	 </tr>
	 <tr>
	<td><b>Primary Reference</b></td>
	<td><?php echo $primary_ref_name; ?></td>
	 </tr>

     <tr>
	<td><b>Added On:</b></td>
	<td><?php echo $createon; ?></td>
	 </tr>
	 

     <?php

     if ($resume != NULL) {
         ?>

     <tr>
	<td><b>Resume File</b></td>
	<td><iframe src="resume/<?php echo $resume; ?>" width="100%" height="600px;"></iframe></td>
	 </tr>
     <?php
     }
     ?>

	</table>
    

