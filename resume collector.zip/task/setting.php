<?php
error_reporting(0);
            include('config.php');
            session_start();
            $session_username = $_SESSION['username'];
if($session_username=="")
{
 header("Location: logout.php");
}
                // $admin_id  = $_GET['admin_id'];
// $todaysdate = date("y-m-d");
if (isset($_POST['Save1'])) {

  $company_name = $_POST['company_name'];
  $company_logo = $_POST['company_logo'];
  $tag_line = $_POST['tag_line'];
  $address = $_POST['address'];
  $admin_password = $_POST['admin_password'];

  if ($company_name != "" && $tag_line != "") {

        $update = "UPDATE `settingmaster`
    set
 
    `company_name`='$company_name',
    -- `company_logo`='$company_logo',
     `tag_line`='$tag_line',
     `address`='$address',
     `admin_password`='$admin_password'
    WHERE `admin_id` ='1'";
     //   echo $update;

     $data = mysqli_query($conn, $update);
     
$target_dir = "company_logo/";

$target_file = $target_dir . basename($_FILES["company_logo"]["name"]);
$imagename = basename($_FILES["company_logo"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

if (move_uploaded_file($_FILES["company_logo"]["tmp_name"], $target_file)) {

    $updateprofilephotoquery = mysqli_query($conn, "update settingmaster set `company_logo`='$imagename' where `admin_id`='1'");
    echo $updateprofilephotoquery;
} else {
  echo "Sorry, there was an error uploading your file.";
}


     $success_msg = " Update Succefully !";
    } else {
        $error_msg = "Error  !";
    }
    ;

    // $lastempid = mysqli_insert_id($conn);

}     

$selectquery = mysqli_query($conn, "select * from `settingmaster` where admin_id='1'");

while ($fetchdata = mysqli_fetch_array($selectquery)) {
    $admin_id  = $fetchdata['admin_id'];
    $company_name = $fetchdata['company_name'];
    $company_logo = $fetchdata['company_logo'];
    $tag_line = $fetchdata['tag_line'];
    $address = $fetchdata['address'];
    $admin_password = $fetchdata['admin_password'];

}

?>
<?php 


?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>setting</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</head>
<body>

<?php include('navbar.php'); ?>

<body>

<?php
                if ($success_msg != "") {
                    ?>
                    <div class="alert alert-success">
                        <strong>Success!</strong>
                        <?php echo $success_msg; ?>
                    </div>
                    <?php
                }
                if ($error_msg != "") {
                    ?>
                    <div class="alert alert-danger">
                        <strong>Error!</strong>
                        <?php echo $error_msg; ?>
                    </div>
                    <?php
                }
                ?>

    <form action="setting.php" method="post" enctype="multipart/form-data">
    
    <div class="text-center">
    <h3>Admin Page</h3>
    </div>
    <div class="container mt-3 mb-3 col-md-4 " style="background-color: #f0f2f5;">

        <img src="company_logo/<?php  echo $company_logo; ?>" alt="" width="" height=""style="margin-left:90px; margin-top:10px;"><br>

    <label for="">Company Name</label><br>
    <input type="text" class="form-control" placeholder="Enter Company Name" name="company_name" value="<?php echo $company_name; ?>"><br>

    <label for="">Company Logo</label><br>
    <input type="file" class="form-control"  placeholder="" name="company_logo"  value="<?php echo $company_logo; ?>"><br>

    <label for="">Tag Line</label><br>
    <input type="text" class="form-control" placeholder="" name="tag_line"  value="<?php echo $tag_line; ?>"><br>

    <label for="">Address</label><br>
    <input type="text"class="form-control" placeholder="Enter Address" name="address" value="<?php echo $address; ?>"><br>

    <label for="">Super_Admin Password</label><br>
    <input type="password" class="form-control"  placeholder="Enter Password" name="admin_password"  value="<?php echo $admin_password; ?>"><br>

    <input type="submit" class="btn btn-primary col-md-5 mx-5 my-3" name="Save1" value="save">
    </div>

    </form>
</body>
</html>