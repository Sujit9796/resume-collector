<?php

session_start();
session_destroy();
header("Location: admin_login.php?msg=You are successfully logged out!");

?>