<?php
error_reporting(0);
$servername = "localhost";
$username = "root";
$password = "Mysql@123";
$dbname = "resume_db";


$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
else{
    // mysqli_select_db(company_db);
    // echo("database is connected");
}


?>
 