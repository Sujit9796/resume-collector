<?php
error_reporting(0);
            include('config.php');
            session_start();
            $session_username = $_SESSION['username'];
if($session_username=="")
{
 header("Location: logout.php");
}

                $employee_id = $_GET['employee_id'];
// $todaysdate = date("y-m-d");
if (isset($_POST['Save1'])) {

  $emp_name = $_POST['emp_name'];
  $email_id = $_POST['email_id'];
  $mobile_no = $_POST['mobile_no'];
  

  if ($emp_name != "" && $mobile_no != "") {

        $update = "UPDATE `employeemaster`
    set
 
    `emp_name`='$emp_name',
    `email_id`='$email_id',
     `mobile_no`='$mobile_no'
    WHERE `employee_id` =$employee_id";

     $data = mysqli_query($conn, $update);

     $success_msg = " Update Succefully !";
    } else {
        $error_msg = "Error  !";
    }
    ;

    // $lastempid = mysqli_insert_id($conn);

}     

$selectquery = mysqli_query($conn, "select * from `employeemaster` where employee_id = '$employee_id'");

while ($fetchdata = mysqli_fetch_array($selectquery)) {
    $employee_id = $fetchdata['employee_id'];
    $emp_name = $fetchdata['emp_name'];
    $email_id = $fetchdata['email_id'];
    $mobile_no = $fetchdata['mobile_no'];

}

?>


<?php include('navbar.php'); ?>

<body>

<?php
                if ($success_msg != "") {
                    ?>
                    <div class="alert alert-success">
                        <strong>Success!</strong>
                        <?php echo $success_msg; ?>
                    </div>
                    <?php
                }
                if ($error_msg != "") {
                    ?>
                    <div class="alert alert-danger">
                        <strong>Error!</strong>
                        <?php echo $error_msg; ?>
                    </div>
                    <?php
                }
                ?>

           <h2 class="text-center text-secondary mt-4 mb-2">Employee</h2>


           <div class="container  mb-3 col-md-4 pt-4" >

<form action="employee_details_update.php?employee_id=<?php echo $employee_id; ?>" method="post" class=" border border-secondary " style="background-color:#f0f2f5">
   
    
    <div class="mb-3 col-md-9  mx-5">
        
        <label for="" class="form-label mb-3 mt-3"> Employee Name</label>
            
            <input type="text" class="form-control " id="" name="emp_name" value="<?php echo $emp_name; ?>">

            <label for="" class="form-label mb-3">Email</label>
            <input type="text" class="form-control " id="" name="email_id" value="<?php echo $email_id; ?>">

            <label for="" class="form-label mb-3">Mobile</label>
            <input type="text" class="form-control " id="" name="mobile_no" value="<?php echo $mobile_no; ?>">
        </div>

        <div class="text-center">
        <input type="submit" class="btn btn-primary  text-center mx-5 my-2" name="Save1" value="Save">
        <a href="employee_details_list.php" class="btn btn-primary  text-center "  name="Emp_list">Cancel</a>
        
        </div>
</form>
    </div>
    
</body>
</html>