<?php
error_reporting(0);
            include('config.php');
                session_start();
                $todaysdate = date('Y-m-d');
// $application_id = $_GET['application_id'];

if (isset($_POST['submit'])) {
    $application_type = $_POST['application_type'];
    $education_status = $_POST['education_status'];
    $profile_photo = $_POST['profile_photo'];
    $course_name = $_POST['course_name'];
    $stream = $_POST['stream'];
    $college_name = $_POST['college_name'];
    $passing_year = $_POST['passing_year'];
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $address = $_POST['address'];
    $resume = $_POST['resume'];
    $primary_ref = $_POST['primary_ref'];
    $secondary_ref = $_POST['secondary_ref'];
    $createon = $_POST['createon'];
  
    if ($application_type != "" && $primary_ref != "") {
  
      // $sql = mysqli_query($conn, "INSERT INTO `employeemaster` (`employee_id`, `fullname`, `emp_code`, `mobile`, `city`, `salary`, `createon`) VALUES (NULL, '$fullname', '$emp_code', '$mobile', '$city', '$salary','$todaysdate')");
  
  
      $insert = mysqli_query($conn, "insert into `resumemaster`
      set 
      `application_type`='$application_type',
      `education_status`='$education_status',
      `profile_photo`='$profile_photo',
      `course_name`='$course_name',
      `stream`='$stream',
      `college_name`='$college_name',
      `passing_year`='$passing_year',
      `fullname`='$fullname',
      `email`='$email',
      `mobile`='$mobile',
      `dob`='$dob',
      `gender`='$gender',
      `address`='$address',
      `primary_ref`='$primary_ref',
      `secondary_ref`='$secondary_ref',
      `createon`='$todaysdate'

      ");
  
      
      $lastempid = mysqli_insert_id($conn);
      
      ?>
<?php
$target_dir = "profile_photo/";

    $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
    $imagename = basename($_FILES["fileToUpload"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {

        $updateprofilephotoquery = mysqli_query($conn, "update resumemaster set `profile_photo`='$imagename' where `resume_id`='$lastempid'");
    } else {
      echo "Sorry, there was an error uploading your file.";
    }


    $target_dir = "resume/";

    $target_file = $target_dir . basename($_FILES["resume"]["name"]);
    $imagename1 = basename($_FILES["resume"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    
    if (move_uploaded_file($_FILES["resume"]["tmp_name"], $target_file)) {

        $updateprofilephotoquery = mysqli_query($conn, "update resumemaster set `resume`='$imagename1' where `resume_id`='$lastempid'");
    } else {
      echo "Sorry, there was an error uploading your file.";
    }
    


    
    $success_msg = "Employee added successfully!";
    } else {
      $error_msg = "Please enter application_type & primary_ref!";
    }
    
    
    }       

 

    ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<?php
                if ($success_msg != "") {
                    ?>
                    <div class="alert alert-success">
                        <strong>Success!</strong>
                        <?php echo $success_msg; ?>
                    </div>
                    <?php
                }
                if ($error_msg != "") {
                    ?>
                    <div class="alert alert-danger">
                        <strong>Error!</strong>
                        <?php echo $error_msg; ?>
                    </div>
                    <?php
                }
                ?>

      <h1 style="text-align:center;">Resume Collector</h1>
<form action="resume.php" method="post" enctype="multipart/form-data">
    <div class="container col-md-4 mt-3 pt-3" style="background-color:#f0f2f5">

    <label for="gender">Application Type </label>
        <select class="form-control" name="application_type" >
            <option selected disabled>--Select Application Type--</option>
            <?php  
           $getapptype = mysqli_query($conn, "SELECT * FROM `applicationtypemaster`");

           while ($dataapptype = mysqli_fetch_array($getapptype)) {
               $application_id  = $dataapptype['application_id'];
               $app_type = $dataapptype['app_type'];
           ?>
           <option value="<?php echo $application_id; ?>"><?php echo $app_type; ?></option>
           <?php
           }
           ?>
        </select>
        <br>
        <label for="gender">Education Status</label>
        <select class="form-control" name="education_status" >
            <option selected disabled>--Select Education Status--</option>
            <?php  
           $getapptype = mysqli_query($conn, "SELECT * FROM `educationstatusmaster`");

           while ($dataapptype = mysqli_fetch_array($getapptype)) {
               $education_id  = $dataapptype['education_id'];
               $education_status = $dataapptype['education_status'];
           ?>
           <option value="<?php echo $education_id; ?>"><?php echo $education_status; ?></option>
           <?php
           }
           ?>
        </select>
        <br>
        
        
  <label for=" " >Profile Photo</label>
  <input type="file" name="fileToUpload" id="fileToUpload"  accept="image/*"><br><br>

  <label for=" " >Course Name:</label>
  <input type="text" id=" " name="course_name" class="form-control"><br>

  <label for=" " >Stream:</label>
  <input type="text" id=" " name="stream" class="form-control"><br>

  <label for=" " >College Name:</label>
  <input type="text" id=" " name="college_name" class="form-control"><br>

  <label for=" " >Year Of Passing:</label>
  <input type="text" id=" " name="passing_year" class="form-control"><br>

  <label for=" " >Full Name</label>
  <input type="text" id=" " name="fullname" class="form-control"><br>

  <label for=" " >Email</label>
  <input type="text" id=" " name="email" class="form-control"><br>

  <label for=" " >Mobile</label>
  <input type="text" id=" " name="mobile" class="form-control"><br>

  <label for=" " >Date Of Birth</label>
  <input type="date" id=" " name="dob" class="form-control"><br>

  <label for="gender">Gender</label>
        <select class="form-control" name="gender" >
            <option selected disabled>--Select Gender--</option>
           <option> Male</option>
           <option>Female</option>
           <option>Other</option>

        </select>
        

  <label for=" " >Address</label>
  <input type="text" id=" " name="address" class="form-control"><br>

  
      <label for=" " >Upload Resume</label>
      <input type="file" id=" " name="resume" class="form-control" accept="application/pdf"><br>
            

  <label for=" ">Primary Reference</label>
        <select class="form-control" name="primary_ref" >
            <option selected disabled>--Select Primary Reference--</option>

            <?php  
           $getapptype = mysqli_query($conn, "SELECT * FROM `employeemaster`");

           while ($dataapptype = mysqli_fetch_array($getapptype)) {
               $employee_id  = $dataapptype['employee_id'];
               $emp_name = $dataapptype['emp_name'];
           ?>
           <option value="<?php echo $employee_id; ?>"><?php echo $emp_name; ?></option>
           <?php
           }
           ?>

        </select>
        <br>

        <label for=" " >Secondary Reference</label>
  <input type="text" id=" " name="secondary_ref" class="form-control"><br>

  
    

  <input type="submit" class="btn btn-primary mb-3" value="Submit" name="submit">
</div>
</form>
    
</body>
</html>