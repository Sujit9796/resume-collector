<?php
error_reporting(0);
            include('config.php');
            session_start();
            $session_username = $_SESSION['username'];
if($session_username=="")
{
 header("Location: logout.php");
}
// $todaysdate = date("y-m-d");
if (isset($_POST['Save1'])) {

  $emp_name = $_POST['emp_name'];
  $email_id = $_POST['email_id'];
  $mobile_no = $_POST['mobile_no'];
  

  if ($emp_name != "" && $mobile_no != "") {

    // $sql = mysqli_query($conn, "INSERT INTO `employeemaster` (`employee_id`, `fullname`, `emp_code`, `mobile`, `city`, `salary`, `createon`) VALUES (NULL, '$fullname', '$emp_code', '$mobile', '$city', '$salary','$todaysdate')");


    $insert = mysqli_query($conn, "insert into `employeemaster`
	set 
	`emp_name`='$emp_name',
	`email_id`='$email_id',
    `mobile_no`='$mobile_no'
	
	");

    $lastempid = mysqli_insert_id($conn);

    $success_msg = "Employee added successfully!";
} else {
  $error_msg = "Please enter application_type & description_app!";
}


}       


?>

<?php include('navbar.php'); ?>

<body>

<?php
                if ($success_msg != "") {
                    ?>
                    <div class="alert alert-success">
                        <strong>Success!</strong>
                        <?php echo $success_msg; ?>
                    </div>
                    <?php
                }
                if ($error_msg != "") {
                    ?>
                    <div class="alert alert-danger">
                        <strong>Error!</strong>
                        <?php echo $error_msg; ?>
                    </div>
                    <?php
                }
                ?>


<h2 class="text-center text-secondary mt-4">Employee</h2>
    <div class="container  mb-3 col-md-4 pt-4" >

<form action="employee_details.php" method="post" class=" border border-secondary " style="background-color:#f0f2f5">



<div class="mb-3 col-md-9  mx-5">
            <label for="" class="form-label mb-3 mt-3"> Employee Name</label>
            <input type="text" class="form-control " id="" name="emp_name">

            <label for="" class="form-label mb-3">Email</label>
            <input type="text" class="form-control " id="" name="email_id">

            <label for="" class="form-label mb-3">Mobile</label>
            <input type="text" class="form-control " id="" name="mobile_no">
        </div>

        <div class="text-center">
        <input type="submit" class="btn btn-primary col-md-3 text-center   mx-3  mb-3" name="Save1" value="Save">
        <button class="btn btn-primary mt-2 mb-4">
                   <a href="employee_details_list.php" class="text-white col-md-3 text-center  mx-3  mb-3 text-decoration-none">Cancel</a>
                </button>
        
        </div>
</form>
    </div>
    
</body>
</html>