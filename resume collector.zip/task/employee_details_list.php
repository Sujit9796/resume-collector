<?php
      error_reporting(0);
            include('config.php');
            session_start();
            $session_username = $_SESSION['username'];
if($session_username=="")
{
header("Location: logout.php");
}

                $employee_id = $_GET['employee_id'];

                if($employee_id!= "") 
{
  $deleterecord = mysqli_query($conn, "delete from `employeemaster` where employee_id='$employee_id' ");
	$success_msg = "Record Deleted Successfully!";
  echo $success_msg;
}

?>

<!DOCTYPE html>
<html>
<head>
<style>

</style>
</head>
<body>

<?php include('navbar.php'); ?>

<div class="text-end mx-5 mt-4">
<button class="btn btn-secondary mt-3 mb-3">
  <a href="employee_details.php" class="text-white text-decoration-none">Add Employee Details</a>
</button>
</div>

<h4 class="mb-4 text-center py-3">List Of Employee Details</h4>

<!-- <table id="customers"> -->
<table class="table table-bordered table-hover">
  <thead class=" bg-secondary text-white">
  <div class="container-fluid">
  <tr>
    <th>Employee ID</th>
    <th>Employee Name</th>
    <th>Email ID</th>
	  <th>Mobile No</th>
    <th>Edit</th>
    <th>Delete</th>
	 
  </tr>
  </div>
</thead>


  <?php
   $selectquery = mysqli_query($conn, "select * from `employeemaster`");

  while ($fetchdata = mysqli_fetch_array($selectquery)) {
      $employee_id = $fetchdata['employee_id'];
      $emp_name = $fetchdata['emp_name'];
      $email_id = $fetchdata['email_id'];
      $mobile_no = $fetchdata['mobile_no'];

      ?>

<td><?php echo $employee_id; ?></td>
	<td><?php echo $emp_name; ?></td>
	<td><?php echo $email_id; ?></td>
    <td><?php echo $mobile_no; ?></td>
	
	<!-- <td><a href="add_photo.php?application_id=<?php echo $employee_id; ?>">Add Photo</a></td> -->

	<!-- <td><a href="view_employee.php?application_id=<?php echo $employee_id; ?>">View</a></td> -->
	<td><a href="employee_details_update.php?employee_id=<?php echo $employee_id; ?>">Edit</a></td>
	<td><a href="employee_details_list.php?employee_id=<?php echo $employee_id; ?>" onclick="return confirm('do you want to delete this record?');">Delete</a></td>
	 
	</tr>
   <?php

        }

   ?>

</table>
</body>
</html>